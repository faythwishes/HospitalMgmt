/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package hospitalmanagementsystem;

import java.awt.Color;
import java.awt.Component;
import java.util.List;
import javax.swing.JTable;
import javax.swing.table.DefaultTableCellRenderer;

/**
 *
 * @author Faith
 */
public class HospitalManagementSystem extends DefaultTableCellRenderer {
    
    private Component component;

    @Override
    public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
        component = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/OverriddenMethodBody

//        if (row % 2 == 0) {
//            component.setBackground(Color.cyan);
//        } else {
//            component.setBackground(Color.pink);
//        }
//        if (isSelected) {
//            component.setBackground(Color.magenta);
//        }


 String reason = (String)table.getModel().getValueAt(row, column);
    if ("Follow Up".equals(reason)) {
      setBackground(Color.RED);
      setForeground(Color.WHITE);
    } 
      
    else if ("Broken Leg".equals(reason)) {
      setBackground(Color.BLUE);
      setForeground(Color.WHITE);
    } 
    else if ("Fever".equals(reason)) {
      setBackground(Color.GREEN);
      setForeground(Color.WHITE);
    }
    else {
      setBackground(table.getBackground());
      setForeground(table.getForeground());
    } 
        return component;

    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        ManagementForm mform = new ManagementForm();
        mform.setVisible(true);
    }

}
